package com.ust.scart.service;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.scart.model.Cart;
import com.ust.scart.repository.CartRepository;

@SpringBootTest
public class CartServiceTest {
	
	@Autowired
	private CartRepository cartRepository;
	private Cart cart;
	
	@Autowired
	private CartService cartService;
	

	@BeforeEach
	public void setUp() throws Exception {
		cart = new Cart();
		cart.setCartUserName("eldhose");
		cart.setCartProductId(101);
		cart.setCartProductName("table");		
		cart.setCartProductPrice(1000);
		cart.setCartProductQuantity(2);
		cart.setCartProductPriceTotal(cart.getCartProductPrice()*cart.getCartProductQuantity());

		cartService.saveProductToCart(cart);
	}

	@AfterEach
	public void tearDown() throws Exception {
		
		cartService.deleteProductFromCart(cart.getCartId());
	}

	@Test
	public void testGetCart() {
		List<Cart> cartItem = (List<Cart>) cartService.getCart();
		//List<Cart> productList = (List<Cart>) cartRepository.findAll();
		assertTrue(cartItem.size()>0);
	}

	@Test
	public void testGetCarts() {
		//List<Cart> cartItem = (List<Cart>) cartService.getCart();
		//int cartItemId = cartItem.get(0).getCartId();
		int cartItemId = cart.getCartId();
		Cart rtvCart = (Cart) cartService.getCarts(cartItemId);
		assertEquals(cartItemId, rtvCart.getCartId());
	}

	@Test
	public void testSaveProductToCart() {
	
		//cartService.saveProductToCart(cart);
		Integer cartItemId = cart.getCartId();		
		Optional<Cart> retvSavedProduct = cartRepository.findById(cartItemId);
	    assertEquals("table", retvSavedProduct.get().getCartProductName());
		
	}

	@Test
	public void testDeleteProductFromCart() {
		Cart cart = new Cart();		
		cart.setCartUserName("eldhose");
		cart.setCartProductId(102);
		cart.setCartProductName("chair");		
		cart.setCartProductPrice(800);
		cart.setCartProductQuantity(2);
		cart.setCartProductPriceTotal(cart.getCartProductPrice()*cart.getCartProductQuantity());
		
		cartService.saveProductToCart(cart);		
		int cartItemId = cart.getCartId();
		cartService.deleteProductFromCart(cartItemId);
				
		Optional<Cart> retvCartProduct = cartRepository.findById(cartItemId);
		assertEquals(Optional.empty(), retvCartProduct);
	}

	@Test
	public void testUpdateProductCart() {
		Cart cart = new Cart();		
		cart.setCartUserName("eldhose");
		cart.setCartProductId(103);
		cart.setCartProductName("fan");		
		cart.setCartProductPrice(5000);
		cart.setCartProductQuantity(5);
		cart.setCartProductPriceTotal(cart.getCartProductPrice()*cart.getCartProductQuantity());
		
		cartService.saveProductToCart(cart);
		
		cart.setCartProductQuantity(10);
		cart.setCartProductPriceTotal(cart.getCartProductPrice()*cart.getCartProductQuantity());
		
		cartService.updateProductCart(cart);
		
		int cartItemId = cart.getCartId();
		
		Cart cartItem = cartRepository.findById(cart.getCartId()).get();
		assertEquals(10, cartItem.getCartProductQuantity());
		
		cartService.deleteProductFromCart(cartItemId);
		
	}

	
	@Test
	public void testGetProductFromCart() {
		String username = cart.getCartUserName();
		int productId = cart.getCartProductId();
		
		Cart rtvCart = (Cart) cartService.getProductFromCart(username, productId);
		assertEquals(username, rtvCart.getCartUserName());
		//assertEquals(productId, rtvCart.getCartProductId());
		
	}

	@Test
	public void testGetProductsFromCart() {
		String username = cart.getCartUserName();
		
		List<Cart> cartItem = (List<Cart>) cartService.getProductsFromCart(username);
		assertTrue(cartItem.size()>0);
	}

	

}
