package com.ust.scart.service;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.scart.model.Product;
import com.ust.scart.repository.ProductRepository;

@SpringBootTest
public class ProductServiceTest {	
	
	@Autowired
	private ProductRepository productRepository;	
	private Product product;
	
	@Autowired
	private ProductService productService;

	@BeforeEach
	public void setUp() throws Exception {		
		product = new Product(100,"cable",100,100);
		
		productService.saveProduct(product);
	}

	@AfterEach
	public void tearDown() throws Exception {
		 
		productService.deleteProduct(product.getProductId());
	}

	@Test
	public void testGetProducts() {
		//List<Product> productList = (List<Product>) productRepository.findAll();
		List<Product> productList = productService.getProducts();
		
		assertTrue(productList.size()>0);

	}

	@Test
	public void testGetProduct() {
		//Product retvProduct = productRepository.findById(product.getProductId()).get();
		Product retvProduct = productService.getProduct(product.getProductId());
	    
		assertEquals(100, retvProduct.getProductId());
	}

	@Test
	public void testSaveProduct() {
		 //productRepository.save(product);
	     //Product retvProduct = productRepository.findById(product.getProductId()).get();
	     Product retvProduct = productService.getProduct(product.getProductId());
	     assertEquals(100, retvProduct.getProductId());
	}

	@Test
	public void testDeleteProduct() {
		Product product = new Product(101,"wire",90,10);
	    //productRepository.save(product);
	    //productRepository.deleteById(product.getProductId());
		productService.saveProduct(product);
		productService.deleteProduct(product.getProductId());
	   
	    Optional optional = productRepository.findById(product.getProductId());
	    assertEquals(Optional.empty(), optional);
	}

	@Test
	public void testUpdateProduct() {
		product.setPrice(1000);
		//productRepository.save(product);
		productService.updateProduct(product);
	    //Product retvProduct = productRepository.findById(product.getProductId()).get();
	    Product retvProduct = productService.getProduct(product.getProductId());
	    assertEquals(1000, retvProduct.getPrice());
	}

	@Test
	public void testSearchByProductName() {
		//List<Product> retvProduct = productRepository.findByProductName(product.getProductName());
		List<Product> retvProduct = productService.searchByProductName(product.getProductName());
		assertTrue(retvProduct.size()>0);
	}

	@Test
	public void testIsProductExists() {
		//boolean retvProduct = productRepository.existsById(product.getProductId());
		boolean retvProduct = productService.isProductExists(product.getProductId());
		assertTrue(retvProduct);
	}

}
