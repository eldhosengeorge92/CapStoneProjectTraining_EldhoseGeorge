package com.ust.scart.controller;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertTrue;

import org.junit.Before;
import org.junit.Test;

import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.ust.scart.controllertest.AbstractTest;
import com.ust.scart.model.Product;



public class ProductControllerTest extends AbstractTest{
	
/*	@Before
	@Override
	public void setUp() {
		// TODO Auto-generated method stub
		super.setUp();
	}
	
	String uri = "/product";
	
	@Test
	public void testViewAllProducts() throws Exception {
		//get the products
		MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri).accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
		
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		/*
		String content = mvcResult.getResponse().getContentAsString();
		Product productList[] = super.mapFromJson(content, Product[].class);
		
		System.out.println("Product cont :"+productList.length);
		assertTrue(productList.length>0);	
		*/
/*	}
	
	@Test
	public void testSaveProduct() throws Exception {
		
		int productId = 100;
		Product product = new Product(productId, "ssd514", 10,6000);
		
		String inputJson = super.mapToJson(product);
		
		
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.post(uri).contentType(MediaType.APPLICATION_JSON_VALUE).content(inputJson))
				.andReturn();
		
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		/*
		String content = mvcResult.getResponse().getContentAsString();
		assertEquals(content, "Product saved successfully");
		*/
		// this will delete this record which has been inserted for test
		//MockMvcRequestBuilders.delete(uri+"/"+productId);
		
/*	}	
	
	@Test
	public void testDeleteProductById() throws Exception {
		int productId = 100;			
		
		MvcResult mvcResult = mvc.perform(
				MockMvcRequestBuilders.delete(uri+"/"+productId))
				.andReturn();
		
		int status = mvcResult.getResponse().getStatus();
		assertEquals(200, status);
		/*
		String content = mvcResult.getResponse().getContentAsString();
		assertEquals(content, "Product deleted successfully");
		*/
		// this will delete this record which has been inserted for test
		//MockMvcRequestBuilders.delete(uri+"/"+productId);
		
/*	}
	
	@Test
	public void testSearchProductById() throws Exception {
		//get the products
		int productId = 2;
		
				MvcResult mvcResult = mvc.perform(MockMvcRequestBuilders.get(uri+"/"+productId).accept(MediaType.APPLICATION_JSON_VALUE)).andReturn();
				
				int status = mvcResult.getResponse().getStatus();
				assertEquals(200, status);
				/*
				String content = mvcResult.getResponse().getContentAsString();
				Product productList= super.mapFromJson(content, Product.class);
				System.out.println(content);
				*/
/*	}
	
	
	

/*
	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}

	@Test
	void testAddProduct() {
		fail("Not yet implemented");
	}

	@Test
	void testSaveProduct() {
		fail("Not yet implemented");
	}

	@Test
	void testSearchProductByIdForm() {
		fail("Not yet implemented");
	}

	@Test
	void testSearchProductById() {
		fail("Not yet implemented");
	}

	@Test
	void testDeleteProductById() {
		fail("Not yet implemented");
	}

	@Test
	void testViewAllProducts() {
		fail("Not yet implemented");
	}
*/
}
