package com.ust.scart.service;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.*;

import java.util.Optional;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.ust.scart.model.EmailCenter;
import com.ust.scart.repository.EmailRepository;

@SpringBootTest
public class EmailServiceTest {

	@Autowired
	private EmailService emailService;
	
	@Autowired
	private EmailRepository emailRepository;
	
	private EmailCenter emailCenter;
	
	@BeforeEach
	public void setUp() throws Exception {
		emailCenter = new EmailCenter();
		emailCenter.setUsername("abcd");
		emailCenter.setPassword("abcd123");
		emailCenter.setEmailId("abcd@gmail.com");
		
		emailService.saveEmailDetails(emailCenter);
	}

	@AfterEach
	public void tearDown() throws Exception {
		
		emailRepository.deleteById(emailCenter.getUsername());
		
	}

	@Test
	public void testSaveEmailDetails() {
		//emailService.saveEmailDetails(emailCenter);
		String username = emailCenter.getUsername();
		Optional<EmailCenter> userDetails = emailRepository.findById(username);
		assertEquals("abcd", userDetails.get().getUsername());
	}
	
	@Test
	public void testIsUserExists() {
		boolean userCheck = emailService.isUserExists(emailCenter.getUsername());
		assertTrue(userCheck);
	}

	@Test
	public void testGetuserDetails() {
		String username = emailCenter.getUsername();
		EmailCenter userDetails = (EmailCenter) emailService.getuserDetails(username);
		
		assertEquals("abcd", userDetails.getUsername());		
	}

}
