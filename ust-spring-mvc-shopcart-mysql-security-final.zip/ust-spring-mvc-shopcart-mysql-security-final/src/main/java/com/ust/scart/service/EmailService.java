package com.ust.scart.service;

import java.io.IOException;
import java.util.Optional;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Service;

import com.ust.scart.model.EmailCenter;
import com.ust.scart.repository.EmailRepository;

@Service
public class EmailService {
	
	@Autowired
	EmailRepository emailRepository;
	
	@Autowired
    private JavaMailSender javaMailSender;
	
	//------------------------------------------------------- save mail details from registration
	public void saveEmailDetails(EmailCenter emailCenter)
	{
		//this will save the email details in database
		emailRepository.save(emailCenter);
	}
	
	////////////////////////////////////////////////////////////////////////////////
	public void sendmail(String message) throws AddressException, MessagingException, IOException {
		
		String username = null;
		String emailIdToSend = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
			System.out.println("### username is : " + username);			
		}
		
		Optional<EmailCenter> emailDetail = emailRepository.findById(username);
		emailIdToSend = emailDetail.get().getEmailId();
		
		SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(emailIdToSend);

        msg.setSubject("Welcome to Shop Cart App");
        msg.setText(message);

        javaMailSender.send(msg);
		  
		}
	
	
	public void sendmail(String userEmail, String mailSubject, String mailMessage) {
		// TODO Auto-generated method stub
		SimpleMailMessage msg = new SimpleMailMessage();
        msg.setTo(userEmail);

        msg.setSubject(mailSubject);
        msg.setText(mailMessage);

        javaMailSender.send(msg);
	}

	/////////////////////////////////////////////////////////////////////////////////////
	
	public boolean isUserExists(String username) {
		return emailRepository.existsByUsername(username);			
	}
	
	public EmailCenter getuserDetails(String username) {
		Optional<EmailCenter> userDetails = emailRepository.findById(username);
		return userDetails.get();
	}

	
}
