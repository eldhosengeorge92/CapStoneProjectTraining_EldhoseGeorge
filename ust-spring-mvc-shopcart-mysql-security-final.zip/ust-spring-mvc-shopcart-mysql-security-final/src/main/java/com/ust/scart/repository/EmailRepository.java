package com.ust.scart.repository;

import org.springframework.data.repository.CrudRepository;

import com.ust.scart.model.EmailCenter;

public interface EmailRepository extends CrudRepository<EmailCenter, String> {

	boolean existsByUsername(String username);
	
	

}
