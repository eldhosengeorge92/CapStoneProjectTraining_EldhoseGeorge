package com.ust.scart.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ust.scart.model.Cart;
import com.ust.scart.model.Product;
import com.ust.scart.repository.CartRepository;
import com.ust.scart.repository.ProductRepository;


@Service
public class CartService {
	
	@Autowired
	CartRepository cartRepository; 		
	
	public List<Cart> getCart()
	{
		return (List<Cart>) cartRepository.findAll();
	}
	
	public Cart getCarts(Integer id) {
		Optional<Cart> cart = cartRepository.findById(id);
		return cart.get();
	}
	
	public void saveProductToCart(Cart cart)
	{
		//this will save the product in database
		cartRepository.save(cart);
	}
	
	public void deleteProductFromCart(Integer noId)
	{
		cartRepository.deleteById(noId);
	}

	public void updateProductCart(Cart cart) 
	{
		//save or update
		cartRepository.save(cart);		
		
	}
	
	public Cart getProductFromCart(String username, int productId) {
		// TODO Auto-generated method stub
		return cartRepository.findByCartUserNameAndCartProductId(username, productId);
	}

	public List<Cart> getProductsFromCart(String username) {
		// TODO Auto-generated method stub
		return cartRepository.findByCartUserName(username);
	}

}
