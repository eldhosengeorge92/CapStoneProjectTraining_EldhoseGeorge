package com.ust.scart.security;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.crypto.password.NoOpPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.JdbcUserDetailsManager;

//import com.ust.pms.service.MyUserDetailService;

@EnableWebSecurity
public class SecurityConfigurer extends WebSecurityConfigurerAdapter{
	
/*
	@Autowired
	private MyUserDetailService myUserDetailService;
	
	@Override
	protected void configure(AuthenticationManagerBuilder auth) throws Exception {
		
		auth.userDetailsService(myUserDetailService);	
	}
	
*/
/*
	
	// In memory authentication	
	@Autowired
	public void configureGlobal(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception{
		
		authenticationManagerBuilder.inMemoryAuthentication()
			.withUser("eldhose").password("eng123").authorities("ROLE_ADMIN").and()
			.withUser("george").password("g12345").authorities("ROLE_USER").and()
			.withUser("eng").password("123456").authorities("ROLE_ADMIN", "ROLE_USER");
			
	}
*/	
	//=============================================================
	// when username & password are stored in msql database
	@Autowired
	DataSource dataSource;
	
	//Enable JDBC connection
	@Autowired
	public void configAuthentication(AuthenticationManagerBuilder authenticationManagerBuilder) throws Exception{
		authenticationManagerBuilder.jdbcAuthentication().dataSource(dataSource);
	}
	
	//===============================================================
	// authorization
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		
		http.authorizeRequests()
				.antMatchers("/").permitAll()
				.antMatchers("/register", "/forgetPasswordForm", "/forgetPassword").permitAll()
				.antMatchers("/index").hasAnyRole("USER","ADMIN")
				.antMatchers("/viewAllProducts","/cart").hasAnyRole("USER","ADMIN")
				.antMatchers("/addProduct").hasAnyRole("ADMIN")				
				.anyRequest().authenticated().and().formLogin().loginPage("/login").permitAll().and().logout().permitAll();
		
		//cross site request forgery
		
		http.csrf().disable();
	}
		
	
	@Bean
	public PasswordEncoder passwordEncoder() {
		
		return NoOpPasswordEncoder.getInstance();
	}
	
	
	@Bean
	public JdbcUserDetailsManager jdbcUserDetailsManager() {
		
		 JdbcUserDetailsManager jdbcUserDetailsManager = new JdbcUserDetailsManager();
		 jdbcUserDetailsManager.setDataSource(dataSource);		 
		 return jdbcUserDetailsManager;
	}
	
}
