package com.ust.scart.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.servlet.ModelAndView;

import com.ust.scart.model.Product;
import com.ust.scart.service.ProductService;

@Controller
public class ProductController {

	@Autowired
	ProductService productService;

	// ##########################################################################################
	// add product and save################################
	@RequestMapping("/addProduct")
	public ModelAndView addProduct() {
		// command
		return new ModelAndView("addProduct", "command", new Product());
		// return "addProduct";
	}

	@RequestMapping("/saveProduct")
	public ModelAndView saveProduct(Product product) {
		productService.saveProduct(product);

		return new ModelAndView("success", "what", "Product");
	}

	// #####################################################################################
	// search Product By Id ##################################
	@RequestMapping("/searchProductByIdForm")
	public ModelAndView searchProductByIdForm() {

		return new ModelAndView("searchProductByIdForm", "command", new Product());
	}

	@RequestMapping("/searchProductById")
	public ModelAndView searchProductById(Product product) {

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("searchProductByIdForm");

		int pId = product.getProductId();

		if (productService.isProductExists(pId)) {
			Product productDetails = productService.getProduct(pId);
			modelAndView.addObject("command", productDetails);
		} else {
			modelAndView.addObject("command", new Product());
			modelAndView.addObject("msg", "Product with Product Id: " + pId + " does not exists...!");
		}

		return modelAndView;
	}
	// #####################################################################################
	// delete Product By Id #####################################

	// delete functionality in spring boot mvc
	@RequestMapping("/deleteProductById")
	public ModelAndView deleteProductById(Product product) {

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("searchProductByIdForm");
		modelAndView.addObject("command", new Product());

		int pId = product.getProductId();

		if (productService.isProductExists(pId)) {
			productService.deleteProduct(pId);
			modelAndView.addObject("msg", "Product with Product Id: " + pId + " deleted successfully...!");

		} else {
			modelAndView.addObject("msg", "Product with Product Id: " + pId + " does not exists...!");
		}

		return modelAndView;
	}
	// ############################################################################################
	// view All Products ##################################################

	// fetch all the products
	@RequestMapping("/viewAllProducts")
	public ModelAndView viewAllProducts() {
		List<Product> products = productService.getProducts();
		return new ModelAndView("viewAllProducts", "products", products);
	}
	// ###############################################################################################################################################

}
