package com.ust.scart.controller;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.provisioning.JdbcUserDetailsManager;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.ust.scart.model.EmailCenter;
import com.ust.scart.model.Product;
import com.ust.scart.model.UserRegistration;
import com.ust.scart.repository.EmailRepository;
import com.ust.scart.service.EmailService;

@Controller
public class IndexController {
	
	@Autowired
	EmailService emailService;
	
	@Autowired
	EmailRepository emailRepository;

	// ---------------------------------------------------------------------------
	// about
	@RequestMapping("/")
	public ModelAndView about() {

		String username = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();

			System.out.println("### username is : " + username);
		}
		ModelAndView view = new ModelAndView();
		view.addObject("username", username);
		view.setViewName("about");
		return view;
	}

	// ----------------------------------------------------------------------------
	// Index
	@RequestMapping("/index")
	public ModelAndView index() {

		String username = null;
		String userrole = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if (principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
			userrole = ((UserDetails) principal).getAuthorities().toString();

			System.out.println("### username is : " + username);
			System.out.println("### username is : " + userrole);
		}
			

		if(userrole.equals("[ROLE_ADMIN]"))
		{
			ModelAndView view = new ModelAndView();
			view.addObject("username", username);
			view.setViewName("index");
			return view;
		}
		else
		{
			ModelAndView view = new ModelAndView();
			view.addObject("username", username);
			view.setViewName("indexForUser");
			return view;
		}
	}

	@RequestMapping("/product")
	public String product() {
		return "product";
	}

	// -------------------------------------------------------------------- for
	// custom login form
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public String login(Model model, String error, String logout) {

		if (error != null) {
			model.addAttribute("errorMsg", "Your username or password are Incorrect...!");
		}
		if (logout != null) {
			model.addAttribute("logoutMsg", "You have been successfully logged out...");
		}
		return "login";
	}

	// --------------------------------------------------------------- registration
	// code
	@Autowired
	JdbcUserDetailsManager jdbcUserDetailsManager;

	@RequestMapping(value = "/register", method = RequestMethod.GET)
	public ModelAndView register() {
		return new ModelAndView("registration", "user", new UserRegistration());
	}

	@RequestMapping(value = "/register", method = RequestMethod.POST)
	public ModelAndView registerUser(@ModelAttribute("user") UserRegistration userRegistration) {

		// authorities to be granted
		List<GrantedAuthority> authorities = new ArrayList<GrantedAuthority>();
		authorities.add(new SimpleGrantedAuthority("ROLE_USER"));
		
		//userRegistration.setEmailId(userRegistration.getEmailId());
		EmailCenter emailCenter = new EmailCenter();
		emailCenter.setUsername(userRegistration.getUsername());
		emailCenter.setEmailId(userRegistration.getEmailId());	
		emailCenter.setPassword(userRegistration.getPassword());
		emailService.saveEmailDetails(emailCenter);
		
		User user = new User(userRegistration.getUsername(), userRegistration.getPassword(), authorities);
		jdbcUserDetailsManager.createUser(user);
		
		/////////////////////////////////////
		String username = emailCenter.getUsername();
		String userEmail = emailCenter.getEmailId();
		String mailSubject = "Welcome to ShopCart App ";
		
		String mailMessage = "Hi " +username+", \r\n \r\n"
				+"Welcome to shopcart app. \r\n \r\n"
				+"As a new customer explore the offers in your's favourite shopping destination ShopCart... \r\n \r\n"				
				+"Thank you for shopping with,  \r\n ShopCart (Your's Favourite shopping app";
		emailService.sendmail(userEmail, mailSubject, mailMessage);
		////////////////////////////////////
		
		return new ModelAndView("login", "newloginMsg",	"You have been successfully registered. Please login to proceed...");
	}
	
	///////////////////////////////////////////////////////////////////////////////////////
	
	@RequestMapping("/forgetPasswordForm")
	public ModelAndView forgetPasswordForm() {

		return new ModelAndView("forgetPasswordForm", "command", new EmailCenter());
	}

	@RequestMapping("/forgetPassword")
	public ModelAndView forgetPassword(EmailCenter emailCenter) {

		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("forgetPasswordForm");

		String username = emailCenter.getUsername();		

		if (emailService.isUserExists(username)) 
		{
			EmailCenter userDetails = emailService.getuserDetails(username);
			
			String userPassword = userDetails.getPassword();
			String userEmail = userDetails.getEmailId();
			String mailSubject = "# # # Password Recovery mail...# # # ";
			
			String mailMessage = "Hi " +username+", \r\n \r\n"
					+"Your credentials for the shopcart app is \r\n \r\n"
					+"Your username of the account: "+username+" \r\n \r\n"
					+"Your password of the account: "+userPassword+" \r\n \r\n"
					+"Thank you for shopping with,  \r\n ShopCart (Your's Favourite shopping app";
			emailService.sendmail(userEmail, mailSubject, mailMessage);
			
			return new ModelAndView("login", "newloginMsg",	"Password Recovered and mailed to registered Email. Please check mail and login to proceed...");
		} 
		else 
		{
			modelAndView.addObject("command", new EmailCenter());
			modelAndView.addObject("msg", "User with Username: " + username + " does not exists...!");
			return modelAndView;
		}

		
	}

	
}
