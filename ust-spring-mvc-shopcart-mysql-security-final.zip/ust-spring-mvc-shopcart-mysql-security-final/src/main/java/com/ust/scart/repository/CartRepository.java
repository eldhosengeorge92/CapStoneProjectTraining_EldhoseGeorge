package com.ust.scart.repository;


import java.util.List;

import org.springframework.data.repository.CrudRepository;

import com.ust.scart.model.Cart;




public interface CartRepository extends CrudRepository<Cart, Integer> {

	public List<Cart> findByCartUserName(String cartUserName);
	public Cart findByCartUserNameAndCartProductId(String cartUserName,int cartProductId);
	// public List<Customer> findBybillAmountGreaterThan(int billAmount);
	// public List<Customer> findBybillAmountLessThan(int billAmount);
	//public List<Customer> findByBillAmountBetween(Integer lowerRange, Integer greaterRange);

	// save
	// delete
	// update
}
