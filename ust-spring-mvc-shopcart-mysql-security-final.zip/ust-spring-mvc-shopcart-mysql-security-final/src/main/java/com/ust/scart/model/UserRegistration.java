package com.ust.scart.model;


import lombok.Data;
//@Entity
//@Table(name="users")
@Data
public class UserRegistration {
	//@Id
	private String username;
	private String password;
	private String confirmPassword;
	private String emailId;
	//private short enabled;

}
