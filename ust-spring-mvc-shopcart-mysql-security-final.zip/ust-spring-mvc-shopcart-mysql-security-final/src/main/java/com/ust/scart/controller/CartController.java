package com.ust.scart.controller;

import java.io.IOException;
import java.util.List;

import javax.mail.MessagingException;
import javax.mail.internet.AddressException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.ust.scart.model.Cart;
import com.ust.scart.model.EmailCenter;
import com.ust.scart.model.Product;
import com.ust.scart.service.CartService;
import com.ust.scart.service.EmailService;
import com.ust.scart.service.ProductService;

@Controller
public class CartController {
	
	@Autowired
	private CartService cartService;

	@Autowired
	private ProductService productService;		
	
	@Autowired
	EmailService emailService;
	
	@RequestMapping("/cart/{pId}")
	public ModelAndView addtoCart(@PathVariable("pId") String pId) throws AddressException, MessagingException, IOException {
		ModelAndView view = new ModelAndView();
		
		String msg=null;
		String msgForStock=null;
		String msgForCartLimit=null;
		int id = Integer.parseInt(pId);
		Integer productId = id;
		
		String username = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
		}

						
		
		Cart cartData = cartService.getProductFromCart(username, id);
		
		Product product = productService.getProduct(productId);
		
		List<Cart> cartItems = cartService.getProductsFromCart(username);
		int cartItemStock = cartItems.size();
		
		int productStock = product.getQuantityOnHand();
		
		if(productStock!=0)
		{		
			if(cartData == null&&cartItemStock<=9) {
				Cart cart = new Cart();
				cart.setCartProductId(id);
				cart.setCartProductQuantity(1);
				cart.setCartProductName(product.getProductName());
				cart.setCartUserName(username);
				cart.setCartProductPrice(product.getPrice());
				cart.setCartProductPriceTotal(cart.getCartProductQuantity()*cart.getCartProductPrice());
				
				int pQuantity = product.getQuantityOnHand();
				product.setQuantityOnHand(pQuantity-1);
				productService.updateProduct(product);
				
				cartService.saveProductToCart(cart);
				
				msg =  product.getProductName()+" successfully added to cart";
				String mailMessage = "Hi " +username+", \r\n \r\n"
						+"Thank you for shopping with ShopCart. \r\n \r\n"
						+product.getProductName()+" have add to cart successfully. You can buy it now...  \r\n \r\n"
						+"Thank you for shopping with,  \r\n ShopCart (Your's Favourite shopping app";
				emailService.sendmail(mailMessage);
				
			}
			else if(cartData != null)
			{
					int quantity =  cartData.getCartProductQuantity();
					cartData.setCartProductQuantity(quantity+1);
					cartData.setCartProductPriceTotal(cartData.getCartProductQuantity()*cartData.getCartProductPrice());
					cartService.updateProductCart(cartData);
					
					int pQuantity = product.getQuantityOnHand();
					product.setQuantityOnHand(pQuantity-1);
					productService.updateProduct(product);
					
					
					msg =  product.getProductName()+" successfully added to cart";
					String mailMessage = "Hi " +username+", \r\n \r\n"
							+"Thank you for shopping with ShopCart. \r\n \r\n"
							+product.getProductName()+" have add to cart successfully. You can buy it now...  \r\n \r\n"
							+"Thank you for shopping with,  \r\n ShopCart (Your's Favourite shopping app";
					emailService.sendmail(mailMessage);
				
			
			}
			else
			{
				msg =  "Cart is full. Product NOT successfully added to cart, cart is limit to 10 items...";
				String mailMessage = "Hi " +username+", \r\n \r\n"
						+"Thank you for shopping with ShopCart. \r\n \r\n"
						+"You have reach the cart limit : CART IS FULL...!. So for successfully shopping, purchase the added product's or delete the unwanted product's from your cart. \r\n \r\n"
						+"Thank you for shopping with,  \r\n ShopCart (Your's Favourite shopping app";
				
				emailService.sendmail(mailMessage);
				
			}			
			
		}
		else
		{
			msgForStock =  product.getProductName()+" is out of stock now...!";
			String mailMessage = "Hi " +username+", \r\n \r\n"
					+"Thank you for shopping with ShopCart. \r\n \r\n"
					+product.getProductName()+" you have try to add to cart is out of stock. Stock will be in soon... \r\n \r\n"
					+"Thank you for shopping with,  \r\n ShopCart (Your's Favourite shopping app";
			emailService.sendmail(mailMessage);
		}
			
		List<Cart> cartItem = cartService.getProductsFromCart(username);		
		List<Product> products = productService.getProducts();
		//msg =  product.getProductName()+" successfully added to cart";
		view.addObject("msg",msg);		
		view.addObject("msgForStock",msgForStock);
		view.addObject("username",username);
		view.addObject("cartItem",cartItem);
		//view.addObject("msgForCartLimit",msgForCartLimit);
		view.setViewName("cart");
		
		return  view;

	}
	
	@GetMapping("/cart")
	public ModelAndView getCart() {
		String username = null;
		ModelAndView view = new ModelAndView();
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
		}
		List<Cart> cartItem = cartService.getProductsFromCart(username);
		
		if(cartItem.isEmpty()) {
			EmailCenter userDetails = emailService.getuserDetails(username);	
			String userEmail = userDetails.getEmailId();
			String mailSubject = "# # # ShopCart cart empty notification# # # ";
			
			
			String mailMessage = "Hi " +username+", \r\n \r\n"					
					+"Your shopping cart is empty. \r\n \r\n"
					+"You can order product's to your shopping cart. \r\n \r\n"
					+"Thank you for shopping with,  \r\n ShopCart (Your's Favourite shopping app";
			
			
			emailService.sendmail(userEmail, mailSubject, mailMessage);
		}
		
		view.addObject("username",username);
		view.addObject("cartItem",cartItem);
		view.setViewName("cart");
		return view;
	}
	
	@RequestMapping("/deleteFromCart/{cId}")
	public ModelAndView deleteFromCart(@PathVariable("cId") int cId) {
		String username = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
		}
		
		
		Cart cart = cartService.getCarts(cId);
		Product product = productService.getProduct(cart.getCartProductId());
		if(cart.getCartProductQuantity() == 1) {
			
			int pQuantity = product.getQuantityOnHand();
			product.setQuantityOnHand(pQuantity+1);
			productService.updateProduct(product);
			
			cartService.deleteProductFromCart(cId);
		}
		else 
		{
			cart.setCartProductQuantity(cart.getCartProductQuantity()-1);
			cart.setCartProductPriceTotal(cart.getCartProductQuantity()*product.getPrice());
			cartService.updateProductCart(cart);
			int pQuantity = product.getQuantityOnHand();
			product.setQuantityOnHand(pQuantity+1);
			productService.updateProduct(product);
		}
		List<Cart> cartItem = cartService.getProductsFromCart(username);
		ModelAndView view = new ModelAndView();
		view.addObject("username",username);
		view.addObject("cartItem",cartItem);
		view.setViewName("cart");
		return  new ModelAndView("redirect:/cart");
		
	}
	
	@RequestMapping("/buyFromCart/{cId}")
	public ModelAndView buyFromCart(@PathVariable("cId") int cId) {
		String username = null;
		Object principal = SecurityContextHolder.getContext().getAuthentication().getPrincipal();
		if(principal instanceof UserDetails) {
			username = ((UserDetails) principal).getUsername();
		}
		
		Cart cart = cartService.getCarts(cId);
		Product product = productService.getProduct(cart.getCartProductId());
		
		
		//////////////////////////////////////////////////
		
		EmailCenter userDetails = emailService.getuserDetails(username);	
		String userEmail = userDetails.getEmailId();
		String mailSubject = "# # # Thank you for shopping from ShopCart...# # # ";
		
		
		String mailMessage = "Hi " +username+", \r\n \r\n"
				+"Thank you for shopping from ShopCart. \r\n \r\n"
				+"You have successfully done the payment of Rs."+cart.getCartProductPriceTotal()+" for shopping "+cart.getCartProductQuantity()+" -- "+cart.getCartProductName()+". \r\n \r\n"
				+"Your order will be soon dispatches and shipped to your address. \r\n \r\n"
				+"Thank you for shopping with,  \r\n ShopCart (Your's Favourite shopping app";
		
		
		emailService.sendmail(userEmail, mailSubject, mailMessage);
		/////////////////////////////////////////////
		
		cartService.deleteProductFromCart(cId);
			
		List<Cart> cartItem = cartService.getProductsFromCart(username);
		ModelAndView view = new ModelAndView();
		view.addObject("username",username);
		view.addObject("cartItem",cartItem);
		view.setViewName("cart");
		return new ModelAndView("redirect:/cart");
		
	}
}
