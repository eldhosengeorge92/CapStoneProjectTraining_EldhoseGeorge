package com.ust.scart.model;

import javax.persistence.Entity;
import javax.persistence.Id;

import lombok.Data;

@Entity
@Data
public class EmailCenter {
	@Id
	private String username;
	private String password;
	private String emailId;

}
